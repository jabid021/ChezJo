import "./App.css";
import Accueil from "./components/accueil";
function App() {
  return <Accueil />;
}

export default App;

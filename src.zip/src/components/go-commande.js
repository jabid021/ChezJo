const GoCommande = () => {
  return "";
};

export default GoCommande;

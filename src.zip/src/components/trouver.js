const NousTrouver = () => {
  return "";
};

export default NousTrouver;
